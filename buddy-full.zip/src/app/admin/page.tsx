export default function AdminHome() {
  return (
    <div className="p-8 text-white">
      <h1 className="text-2xl font-semibold">Admin</h1>
      <p className="mt-2 opacity-80">Stub route — admin dashboard goes here.</p>
    </div>
  );
}
