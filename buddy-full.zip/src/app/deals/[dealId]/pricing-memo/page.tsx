import StitchFrame from "@/components/stitch/StitchFrame";

const TITLE = "Buddy - The Underwriter | Pricing + Memo Command Center";
const FONT_LINKS: string[] = [];
const TAILWIND_CDN = "https://cdn.tailwindcss.com?plugins=forms,container-queries";
const TAILWIND_CONFIG_JS = `tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#136dec",
                        "primary-dark": "#0f5bbd",
                        "background-light": "#f6f7f8", // Not used per request spec but kept for config
                        "background-dark": "#0B0E14",
                        "panel-dark": "#151B26",
                        "surface-dark": "#1e2532",
                        "border-dark": "#2d3646",
                        "text-dim": "#94a3b8",
                    },
                    fontFamily: {
                        "display": ["Inter", "sans-serif"],
                        "mono": ["ui-monospace", "SFMono-Regular", "Menlo", "Monaco", "Consolas", "Liberation Mono", "Courier New", "monospace"],
                    },
                    borderRadius: {"DEFAULT": "0.125rem", "sm": "0.125rem", "md": "0.25rem", "lg": "0.375rem", "xl": "0.5rem", "full": "9999px"},
                },
            },
        }`;
const STYLES = [
  "body { font-family: 'Inter', sans-serif; }\n        /* Custom scrollbar for dense data panels */\n        .custom-scrollbar::-webkit-scrollbar {\n            width: 6px;\n            height: 6px;\n        }\n        .custom-scrollbar::-webkit-scrollbar-track {\n            background: #151B26; \n        }\n        .custom-scrollbar::-webkit-scrollbar-thumb {\n            background: #2d3646; \n            border-radius: 3px;\n        }\n        .custom-scrollbar::-webkit-scrollbar-thumb:hover {\n            background: #475569; \n        }"
];
const BODY_HTML = `<!-- 1. Global Header -->
<header class="h-14 shrink-0 border-b border-[#282f39] bg-[#111418] flex items-center justify-between px-6 z-20">
<!-- Left: Branding & Deal Context -->
<div class="flex items-center gap-6">
<div class="flex items-center gap-3">
<div class="size-6 text-primary">
<svg fill="none" viewbox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
<path d="M42.4379 44C42.4379 44 36.0744 33.9038 41.1692 24C46.8624 12.9336 42.2078 4 42.2078 4L7.01134 4C7.01134 4 11.6577 12.932 5.96912 23.9969C0.876273 33.9029 7.27094 44 7.27094 44L42.4379 44Z" fill="currentColor"></path>
</svg>
</div>
<h1 class="text-white text-base font-bold tracking-tight">Buddy <span class="text-text-dim font-normal">| The Underwriter</span></h1>
</div>
<div class="h-6 w-px bg-[#282f39]"></div>
<div class="flex items-center gap-4">
<span class="text-sm font-medium text-white">1500 Broadway - Refinance</span>
<!-- Status Pills -->
<div class="flex gap-2">
<div class="flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
<span class="material-symbols-outlined text-emerald-500 text-[14px]">check_circle</span>
<span class="text-[11px] font-medium text-emerald-500 uppercase tracking-wide">Snapshot: Latest</span>
</div>
<div class="flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
<span class="material-symbols-outlined text-emerald-500 text-[14px]">shield</span>
<span class="text-[11px] font-medium text-emerald-500 uppercase tracking-wide">Risk: Current</span>
</div>
<div class="flex items-center gap-1.5 px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/20">
<span class="material-symbols-outlined text-amber-500 text-[14px]">edit_note</span>
<span class="text-[11px] font-medium text-amber-500 uppercase tracking-wide">Pricing: Draft</span>
</div>
</div>
</div>
</div>
<!-- Right: Actions -->
<div class="flex items-center gap-4">
<div class="flex gap-2">
<button class="flex h-8 items-center gap-2 px-3 bg-[#136dec] hover:bg-primary-dark transition-colors rounded text-white text-xs font-semibold tracking-wide">
<span class="material-symbols-outlined text-[16px]">add_a_photo</span>
                    New Snapshot
                </button>
<button class="flex h-8 items-center gap-2 px-3 bg-[#282f39] hover:bg-[#333b47] transition-colors rounded text-white text-xs font-semibold tracking-wide border border-[#3b4554]">
<span class="material-symbols-outlined text-[16px]">refresh</span>
                    Regen Risk Facts
                </button>
</div>
<div class="h-8 w-8 rounded-full bg-cover bg-center border border-[#3b4554] cursor-pointer relative" data-alt="User profile avatar placeholder showing a generic silhouette" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuB8cg2jvg1NvClGGEk1hOD9SA42JdX4MRrF43Qo7iH3O8MUPQQ5in4bct1BtgsOtrk7QSDluiRTSSmEMH3RCc8OUDJ5QrP9AAi3ga1xyg-WwLszgyS5w9NpYbld79gbXY95fK4TpPHDi4gVITe0xC8brSMFbTv0OP9X2wz7gbKhEiySJgNFSKrlHX6OXTnHb44bgKz8v7B7ZQBcaok7CyBLkJqcb9v7wQxX-gr1cQL9TccuMRshaZsZ75OVRbluaA4w8WOZVLpzIv4');">
<div class="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-emerald-500 border-2 border-[#111418]"></div>
</div>
</div>
</header>
<!-- Main Layout Container -->
<div class="flex flex-1 overflow-hidden">
<!-- 2. Left Navigation Rail -->
<nav class="w-16 shrink-0 bg-[#111418] border-r border-[#282f39] flex flex-col items-center py-4 gap-6 z-10">
<div class="flex flex-col items-center gap-6 w-full">
<button class="group relative flex flex-col items-center justify-center gap-1 text-text-dim hover:text-white transition-colors w-full py-2">
<span class="material-symbols-outlined text-[24px]">camera_alt</span>
<span class="text-[10px] font-medium opacity-0 group-hover:opacity-100 absolute top-8 transition-opacity bg-black px-1 rounded">Snapshot</span>
</button>
<button class="group relative flex flex-col items-center justify-center gap-1 text-text-dim hover:text-white transition-colors w-full py-2">
<span class="material-symbols-outlined text-[24px]">shield_person</span>
</button>
<!-- Active State -->
<button class="relative flex flex-col items-center justify-center gap-1 text-primary w-full py-2">
<div class="absolute left-0 top-1/2 -translate-y-1/2 h-8 w-1 bg-primary rounded-r"></div>
<span class="material-symbols-outlined text-[24px] fill-current">currency_exchange</span>
</button>
<button class="group relative flex flex-col items-center justify-center gap-1 text-text-dim hover:text-white transition-colors w-full py-2">
<span class="material-symbols-outlined text-[24px]">description</span>
</button>
<button class="group relative flex flex-col items-center justify-center gap-1 text-text-dim hover:text-white transition-colors w-full py-2">
<span class="material-symbols-outlined text-[24px]">folder_open</span>
</button>
</div>
</nav>
<!-- Main Content Area -->
<main class="flex flex-1 overflow-hidden">
<!-- LEFT PANEL: Data & Controls (60%) -->
<div class="w-[60%] flex flex-col border-r border-[#282f39] bg-[#0B0E14] overflow-y-auto custom-scrollbar">
<!-- Section A: Snapshot Context -->
<section class="p-6 border-b border-[#282f39] bg-[#151B26]/30">
<div class="flex items-center justify-between mb-3">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-primary text-[20px]">visibility</span>
<h2 class="text-sm font-bold uppercase tracking-wider text-white">Deal Context Snapshot</h2>
</div>
<span class="text-xs text-text-dim font-mono bg-[#282f39] px-2 py-0.5 rounded">ID: SNAP-8821</span>
</div>
<div class="bg-[#151B26] border border-[#282f39] rounded p-4 relative group">
<div class="flex justify-between items-start mb-2 border-b border-[#282f39] pb-2">
<div class="text-xs text-text-dim">Source: <span class="text-white">OM_Nov2023.pdf</span> • Created: <span class="text-white">Today, 09:15 AM</span></div>
<button class="text-xs text-primary hover:text-white font-medium transition-colors">View Source</button>
</div>
<div class="h-20 overflow-y-auto custom-scrollbar text-sm text-gray-300 leading-relaxed font-light">
                            The subject property is a Class A office building located in the Times Square submarket of Manhattan. 
                            Built in 1998 and renovated in 2018, the 32-story tower comprises 450,000 RSF. 
                            Major tenants include TechCorp (35% NRA) and LawFirm LLP (20% NRA). 
                            The sponsor seeks a $45M refinance of the existing senior debt maturing in Dec 2024.
                            Preliminary valuation suggests an as-is value of $72.5M based on a 6.5% cap rate.
                        </div>
<div class="absolute bottom-2 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
<button class="bg-primary/20 hover:bg-primary/40 text-primary hover:text-white text-xs font-semibold px-3 py-1.5 rounded border border-primary/30 backdrop-blur-sm">Use This Context</button>
</div>
</div>
</section>
<!-- Section B: Risk Facts -->
<section class="p-6 border-b border-[#282f39]">
<div class="flex items-center justify-between mb-4">
<h2 class="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
<span class="material-symbols-outlined text-emerald-500 text-[18px]">verified</span>
                            Normalized Risk Facts
                        </h2>
<span class="text-[10px] text-text-dim">Derived from Snapshot #8821</span>
</div>
<div class="grid grid-cols-3 gap-3">
<!-- Metric Card -->
<div class="bg-[#151B26] border border-[#2d3646] p-3 rounded flex flex-col gap-1 relative overflow-hidden group hover:border-primary/50 transition-colors">
<div class="flex justify-between items-start">
<span class="text-[11px] text-text-dim font-medium uppercase tracking-wide">LTV</span>
<div class="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_4px_rgba(16,185,129,0.6)]" title="High Confidence"></div>
</div>
<div class="text-xl font-bold font-mono tracking-tight text-white">62.0%</div>
</div>
<div class="bg-[#151B26] border border-[#2d3646] p-3 rounded flex flex-col gap-1 relative overflow-hidden group hover:border-primary/50 transition-colors">
<div class="flex justify-between items-start">
<span class="text-[11px] text-text-dim font-medium uppercase tracking-wide">DSCR</span>
<div class="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_4px_rgba(16,185,129,0.6)]"></div>
</div>
<div class="text-xl font-bold font-mono tracking-tight text-white">1.35x</div>
</div>
<div class="bg-[#151B26] border border-[#2d3646] p-3 rounded flex flex-col gap-1 relative overflow-hidden group hover:border-primary/50 transition-colors">
<div class="flex justify-between items-start">
<span class="text-[11px] text-text-dim font-medium uppercase tracking-wide">NOI</span>
<div class="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_4px_rgba(16,185,129,0.6)]"></div>
</div>
<div class="text-xl font-bold font-mono tracking-tight text-white">$4.2M</div>
</div>
<div class="bg-[#151B26] border border-[#2d3646] p-3 rounded flex flex-col gap-1 relative overflow-hidden group hover:border-primary/50 transition-colors">
<div class="flex justify-between items-start">
<span class="text-[11px] text-text-dim font-medium uppercase tracking-wide">Loan Amount</span>
<div class="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_4px_rgba(16,185,129,0.6)]"></div>
</div>
<div class="text-xl font-bold font-mono tracking-tight text-white">$45.0M</div>
</div>
<div class="bg-[#151B26] border border-[#2d3646] p-3 rounded flex flex-col gap-1 relative overflow-hidden group hover:border-primary/50 transition-colors">
<div class="flex justify-between items-start">
<span class="text-[11px] text-text-dim font-medium uppercase tracking-wide">As-Is Value</span>
<div class="h-1.5 w-1.5 rounded-full bg-amber-500 shadow-[0_0_4px_rgba(245,158,11,0.6)]" title="Medium Confidence"></div>
</div>
<div class="text-xl font-bold font-mono tracking-tight text-white">$72.5M</div>
</div>
<div class="bg-[#151B26] border border-[#2d3646] p-3 rounded flex flex-col gap-1 relative overflow-hidden group hover:border-primary/50 transition-colors">
<div class="flex justify-between items-start">
<span class="text-[11px] text-text-dim font-medium uppercase tracking-wide">Recourse</span>
<div class="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_4px_rgba(16,185,129,0.6)]"></div>
</div>
<div class="text-xl font-bold font-mono tracking-tight text-white">Non-Recourse</div>
</div>
</div>
</section>
<!-- Section C: Pricing Quote Writer -->
<section class="p-6 flex-1">
<div class="flex items-center justify-between mb-6">
<h2 class="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
<span class="material-symbols-outlined text-primary text-[18px]">tune</span>
                            Pricing Quote <span class="text-amber-500 normal-case bg-amber-500/10 px-1.5 py-0.5 rounded text-[10px] ml-2 font-medium tracking-normal border border-amber-500/20">Draft</span>
</h2>
<div class="flex gap-2">
<button class="text-xs text-text-dim hover:text-white px-3 py-1.5 rounded bg-[#282f39] border border-[#3b4554] transition-colors">Reset to Risk Facts</button>
</div>
</div>
<div class="space-y-6">
<!-- Group 1: Loan Structure -->
<div class="bg-[#151B26] rounded border border-[#2d3646] p-4">
<div class="text-[11px] text-text-dim uppercase font-semibold mb-3 tracking-wider flex items-center gap-2">
<span class="w-1 h-3 bg-primary rounded-full"></span>
                                Loan Structure
                            </div>
<div class="grid grid-cols-2 gap-4">
<div class="flex flex-col gap-1">
<label class="text-[11px] text-gray-400">Product Type</label>
<select class="bg-[#0B0E14] border border-[#2d3646] text-white text-sm rounded h-8 px-2 focus:ring-1 focus:ring-primary focus:border-primary outline-none">
<option>Senior Secured</option>
<option>Mezzanine</option>
<option>Preferred Equity</option>
</select>
</div>
<div class="flex flex-col gap-1">
<label class="text-[11px] text-gray-400">Term (Months)</label>
<input class="bg-[#0B0E14] border border-[#2d3646] text-white text-sm rounded h-8 px-2 focus:ring-1 focus:ring-primary focus:border-primary outline-none font-mono" type="text" value="36"/>
</div>
<div class="flex flex-col gap-1">
<label class="text-[11px] text-gray-400">Amortization</label>
<select class="bg-[#0B0E14] border border-[#2d3646] text-white text-sm rounded h-8 px-2 focus:ring-1 focus:ring-primary focus:border-primary outline-none">
<option>Interest Only</option>
<option>30-Year Schedule</option>
</select>
</div>
<div class="flex flex-col gap-1">
<label class="text-[11px] text-gray-400">Exit Fee</label>
<div class="flex items-center bg-[#0B0E14] border border-[#2d3646] rounded h-8 px-2 focus-within:border-primary">
<input class="bg-transparent text-white text-sm outline-none w-full font-mono" type="text" value="1.00"/>
<span class="text-xs text-text-dim">%</span>
</div>
</div>
</div>
</div>
<!-- Group 2: Pricing Engine -->
<div class="bg-[#151B26] rounded border border-[#2d3646] p-4 relative overflow-hidden">
<div class="absolute right-0 top-0 w-32 h-32 bg-primary/5 rounded-bl-full pointer-events-none"></div>
<div class="text-[11px] text-text-dim uppercase font-semibold mb-3 tracking-wider flex items-center gap-2">
<span class="w-1 h-3 bg-primary rounded-full"></span>
                                Rate Calculator
                            </div>
<div class="flex items-end gap-3">
<div class="flex-1 flex flex-col gap-1">
<label class="text-[11px] text-gray-400">Index (SOFR)</label>
<div class="flex items-center bg-[#0B0E14] border border-[#2d3646] rounded h-10 px-3">
<input class="bg-transparent text-white text-sm outline-none w-full font-mono font-medium" type="text" value="5.32"/>
<span class="text-xs text-text-dim">%</span>
</div>
</div>
<div class="text-text-dim pb-3 font-light text-xl">+</div>
<div class="flex-1 flex flex-col gap-1">
<label class="text-[11px] text-gray-400">Spread (bps)</label>
<div class="flex items-center bg-[#0B0E14] border border-[#2d3646] rounded h-10 px-3">
<input class="bg-transparent text-white text-sm outline-none w-full font-mono font-medium" type="text" value="325"/>
<span class="text-xs text-text-dim">bps</span>
</div>
</div>
<div class="text-text-dim pb-3 font-light text-xl">=</div>
<div class="flex-1 flex flex-col gap-1">
<label class="text-[11px] text-primary font-bold">All-in Rate</label>
<div class="flex items-center bg-primary/10 border border-primary/40 rounded h-10 px-3">
<span class="text-primary text-lg font-bold font-mono">8.57%</span>
</div>
</div>
</div>
</div>
<!-- Group 3: Rationale -->
<div class="bg-[#151B26] rounded border border-[#2d3646] p-4">
<div class="text-[11px] text-text-dim uppercase font-semibold mb-3 tracking-wider flex items-center gap-2">
<span class="w-1 h-3 bg-primary rounded-full"></span>
                                Credit Rationale
                            </div>
<textarea class="w-full bg-[#0B0E14] border border-[#2d3646] text-white text-sm rounded p-3 h-24 focus:ring-1 focus:ring-primary focus:border-primary outline-none resize-none" placeholder="Enter credit rationale and pricing justification here...">Pricing is supported by strong historical occupancy (94% avg last 3 years) and sponsorship's liquidity position ($12M). The spread of 325 bps reflects current market volatility but remains competitive for Class A assets in this submarket.</textarea>
</div>
</div>
<div class="mt-8 flex justify-end gap-3 pb-8">
<button class="px-4 py-2 bg-[#282f39] hover:bg-[#333b47] border border-[#3b4554] rounded text-white text-sm font-medium transition-colors">Save Draft</button>
<button class="px-4 py-2 bg-primary hover:bg-primary-dark rounded text-white text-sm font-medium shadow-lg shadow-primary/20 transition-colors flex items-center gap-2">
<span class="material-symbols-outlined text-[18px]">send</span>
                            Mark as Proposed
                        </button>
</div>
</section>
</div>
<!-- RIGHT PANEL: Output & Intelligence (40%) -->
<div class="w-[40%] flex flex-col bg-[#111418] border-l border-[#282f39]">
<!-- Section D: Quote Preview -->
<section class="p-6 border-b border-[#282f39] flex-shrink-0">
<div class="flex items-center justify-between mb-4">
<h2 class="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
<span class="material-symbols-outlined text-white text-[18px]">preview</span>
                            Live Preview
                        </h2>
</div>
<!-- Paper Card Style -->
<div class="bg-[#f0f0f0] rounded text-[#111418] p-5 shadow-2xl relative overflow-hidden" data-alt="Light colored card resembling a paper document preview">
<div class="flex justify-between items-start mb-4 border-b border-gray-300 pb-2">
<div>
<h3 class="font-bold text-lg leading-tight">Indicative Term Sheet</h3>
<p class="text-[10px] text-gray-500 font-mono mt-1">REF: 1500-BDWY-REF</p>
</div>
<div class="text-right">
<div class="text-2xl font-bold tracking-tight text-[#136dec]">8.57%</div>
<div class="text-[10px] uppercase font-bold text-gray-500">Fixed Rate Equivalent</div>
</div>
</div>
<div class="space-y-3">
<div class="grid grid-cols-2 gap-y-2 text-xs">
<div class="text-gray-500">Loan Amount</div>
<div class="font-bold text-right">$45,000,000</div>
<div class="text-gray-500">LTV / DSCR</div>
<div class="font-bold text-right">62% / 1.35x</div>
<div class="text-gray-500">Term</div>
<div class="font-bold text-right">36 Months (IO)</div>
</div>
<div class="mt-4 pt-3 border-t border-gray-300">
<h4 class="text-[10px] uppercase font-bold text-gray-500 mb-1">Risk Factors &amp; Mitigants</h4>
<ul class="list-disc list-outside ml-3 text-[10px] leading-tight text-gray-700 space-y-1">
<li>Tenant concentration (TechCorp 35%) mitigated by long-term lease (exp 2030).</li>
<li>Market vacancy rising; property outperforms submarket by 400bps.</li>
</ul>
</div>
</div>
</div>
</section>
<!-- Section E: Memo Generator -->
<section class="flex-1 p-6 flex flex-col min-h-0">
<div class="flex items-center justify-between mb-4">
<h2 class="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
<span class="material-symbols-outlined text-white text-[18px]">article</span>
                            Memo Generator
                        </h2>
<span class="text-[10px] text-text-dim">Based on Proposed Pricing</span>
</div>
<div class="flex-1 bg-[#0B0E14] border border-[#2d3646] rounded p-1 overflow-y-auto custom-scrollbar mb-4">
<!-- Checklist Item -->
<div class="flex items-center justify-between p-3 border-b border-[#282f39] hover:bg-[#151B26] transition-colors group">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-emerald-500 text-[18px]">check_circle</span>
<span class="text-sm font-medium text-gray-200">Executive Summary</span>
</div>
<span class="text-[10px] text-emerald-500 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">Ready</span>
</div>
<div class="flex items-center justify-between p-3 border-b border-[#282f39] hover:bg-[#151B26] transition-colors group">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-emerald-500 text-[18px]">check_circle</span>
<span class="text-sm font-medium text-gray-200">Transaction Overview</span>
</div>
<span class="text-[10px] text-emerald-500 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">Ready</span>
</div>
<div class="flex items-center justify-between p-3 border-b border-[#282f39] hover:bg-[#151B26] transition-colors group">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-text-dim text-[18px]">radio_button_unchecked</span>
<span class="text-sm font-medium text-gray-400">Financial Analysis</span>
</div>
<span class="text-[10px] text-text-dim bg-[#282f39] px-1.5 py-0.5 rounded">Pending</span>
</div>
<div class="flex items-center justify-between p-3 border-b border-[#282f39] hover:bg-[#151B26] transition-colors group">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-text-dim text-[18px]">radio_button_unchecked</span>
<span class="text-sm font-medium text-gray-400">Risk Factors</span>
</div>
<span class="text-[10px] text-text-dim bg-[#282f39] px-1.5 py-0.5 rounded">Pending</span>
</div>
<div class="flex items-center justify-between p-3 hover:bg-[#151B26] transition-colors group">
<div class="flex items-center gap-3">
<span class="material-symbols-outlined text-text-dim text-[18px]">radio_button_unchecked</span>
<span class="text-sm font-medium text-gray-400">Appendix &amp; Maps</span>
</div>
<span class="text-[10px] text-text-dim bg-[#282f39] px-1.5 py-0.5 rounded">Pending</span>
</div>
</div>
<button class="w-full py-3 bg-primary hover:bg-primary-dark rounded text-white text-sm font-bold shadow-lg shadow-primary/20 transition-all flex items-center justify-center gap-2 mb-6">
<span class="material-symbols-outlined text-[20px] animate-spin hidden">sync</span> <!-- Hidden spinner state -->
<span class="material-symbols-outlined text-[20px]">bolt</span>
                        Generate Full Credit Memo
                    </button>
<!-- Section F: Generated Outputs -->
<div>
<h3 class="text-[11px] font-bold uppercase tracking-wider text-text-dim mb-3">Output History</h3>
<div class="space-y-2">
<div class="flex items-center justify-between p-2 rounded bg-[#151B26] border border-[#2d3646] hover:border-primary/40 transition-colors group cursor-pointer">
<div class="flex items-center gap-3">
<div class="h-8 w-8 rounded bg-red-500/10 flex items-center justify-center text-red-500">
<span class="material-symbols-outlined text-[18px]">picture_as_pdf</span>
</div>
<div class="flex flex-col">
<span class="text-xs font-medium text-white group-hover:text-primary transition-colors">Pricing_Summary_v2.pdf</span>
<span class="text-[10px] text-text-dim">Today, 10:42 AM • 2.4 MB</span>
</div>
</div>
<span class="material-symbols-outlined text-text-dim hover:text-white text-[18px]">download</span>
</div>
<div class="flex items-center justify-between p-2 rounded bg-[#151B26] border border-[#2d3646] hover:border-primary/40 transition-colors group cursor-pointer">
<div class="flex items-center gap-3">
<div class="h-8 w-8 rounded bg-blue-500/10 flex items-center justify-center text-blue-500">
<span class="material-symbols-outlined text-[18px]">description</span>
</div>
<div class="flex flex-col">
<span class="text-xs font-medium text-white group-hover:text-primary transition-colors">Draft_Memo_v1.0.docx</span>
<span class="text-[10px] text-text-dim">Yesterday, 4:15 PM • 850 KB</span>
</div>
</div>
<span class="material-symbols-outlined text-text-dim hover:text-white text-[18px]">download</span>
</div>
</div>
</div>
</section>
</div>
</main>
</div>`;

export default function Page() {
  return (
    <StitchFrame
      title={TITLE}
      fontLinks={FONT_LINKS}
      tailwindCdnSrc={TAILWIND_CDN}
      tailwindConfigJs={TAILWIND_CONFIG_JS}
      styles={STYLES}
      bodyHtml={BODY_HTML}
    />
  );
}
