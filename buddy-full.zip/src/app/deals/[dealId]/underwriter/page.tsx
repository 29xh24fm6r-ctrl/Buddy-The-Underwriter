import StitchFrame from "@/components/stitch/StitchFrame";

const TITLE = "Deals Command Bridge - Buddy The Underwriter";
const FONT_LINKS: string[] = [];
const TAILWIND_CDN = "https://cdn.tailwindcss.com?plugins=forms,container-queries";
const TAILWIND_CONFIG_JS = `</script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<script>
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#136dec",
                        "primary-hover": "#3b82f6",
                        "bg-dark": "#0f1115",
                        "surface-dark": "#1a1d24",
                        "glass-border": "rgba(255, 255, 255, 0.08)",
                        "glass-bg": "rgba(22, 25, 30, 0.7)",
                        "success": "#10b981",
                        "warning": "#f59e0b",
                        "danger": "#ef4444",
                    },
                    fontFamily: {
                        "display": ["Inter", "sans-serif"],
                        "body": ["Inter", "sans-serif"]
                    },
                    backdropBlur: {
                        'xs': '2px',
                    }
                },
            },
        }`;
const STYLES = [
  "body {\n            font-family: 'Inter', sans-serif;\n            background-color: #0f1115;\n            background-image: radial-gradient(circle at 50% 0%, #1c2333 0%, #0f1115 60%);\n            color: #ffffff;\n        }\n        \n        .glass-panel {\n            background: rgba(26, 29, 36, 0.6);\n            backdrop-filter: blur(16px);\n            -webkit-backdrop-filter: blur(16px);\n            border: 1px solid rgba(255, 255, 255, 0.08);\n            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);\n        }\n\n        .glass-header {\n            background: rgba(15, 17, 21, 0.7);\n            backdrop-filter: blur(12px);\n            -webkit-backdrop-filter: blur(12px);\n            border-bottom: 1px solid rgba(255, 255, 255, 0.08);\n        }\n\n        .nav-active-glow {\n            position: relative;\n        }\n        .nav-active-glow::before {\n            content: '';\n            position: absolute;\n            left: 0;\n            top: 10%;\n            height: 80%;\n            width: 3px;\n            background: #136dec;\n            border-radius: 0 4px 4px 0;\n            box-shadow: 0 0 8px rgba(19, 109, 236, 0.6);\n        }\n\n        /* Custom Scrollbar for dark theme */\n        ::-webkit-scrollbar {\n            width: 8px;\n            height: 8px;\n        }\n        ::-webkit-scrollbar-track {\n            background: transparent;\n        }\n        ::-webkit-scrollbar-thumb {\n            background: rgba(255, 255, 255, 0.1);\n            border-radius: 4px;\n        }\n        ::-webkit-scrollbar-thumb:hover {\n            background: rgba(255, 255, 255, 0.2);\n        }\n\n        .sparkline path {\n            vector-effect: non-scaling-stroke;\n        }\n        \n        .table-row-hover:hover {\n            background-color: rgba(255, 255, 255, 0.03);\n        }\n        .table-row-hover:hover .quick-actions {\n            opacity: 1;\n            pointer-events: auto;\n        }"
];
const BODY_HTML = `<!-- Left Navigation Rail -->
<aside class="w-[88px] flex-shrink-0 flex flex-col items-center py-6 border-r border-glass-border bg-[#0f1115]/80 backdrop-blur-md z-30">
<div class="mb-8">
<!-- Logo Icon Only -->
<div class="size-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-900 flex items-center justify-center shadow-lg shadow-blue-900/20">
<svg fill="none" height="24" viewbox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
<path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="white" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
<path d="M2 17L12 22L22 17" stroke="white" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
<path d="M2 12L12 17L22 12" stroke="white" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
</svg>
</div>
</div>
<nav class="flex flex-col gap-6 w-full">
<button class="group flex flex-col items-center gap-1.5 w-full relative opacity-60 hover:opacity-100 transition-all">
<span class="material-symbols-outlined text-[28px]">dashboard</span>
<span class="text-[10px] font-medium tracking-wide">Command</span>
</button>
<button class="nav-active-glow group flex flex-col items-center gap-1.5 w-full relative text-white transition-all">
<span class="material-symbols-outlined text-[28px] text-primary drop-shadow-[0_0_8px_rgba(19,109,236,0.5)]">bar_chart</span>
<span class="text-[10px] font-medium tracking-wide text-primary">Deals</span>
</button>
<button class="group flex flex-col items-center gap-1.5 w-full relative opacity-60 hover:opacity-100 transition-all">
<span class="material-symbols-outlined text-[28px]">description</span>
<span class="text-[10px] font-medium tracking-wide">Evidence</span>
</button>
<button class="group flex flex-col items-center gap-1.5 w-full relative opacity-60 hover:opacity-100 transition-all">
<span class="material-symbols-outlined text-[28px]">fact_check</span>
<span class="text-[10px] font-medium tracking-wide">Underwriting</span>
</button>
<button class="group flex flex-col items-center gap-1.5 w-full relative opacity-60 hover:opacity-100 transition-all">
<span class="material-symbols-outlined text-[28px]">public</span>
<span class="text-[10px] font-medium tracking-wide">Portal</span>
</button>
<button class="group flex flex-col items-center gap-1.5 w-full relative opacity-60 hover:opacity-100 transition-all">
<span class="material-symbols-outlined text-[28px]">settings_suggest</span>
<span class="text-[10px] font-medium tracking-wide">Ops</span>
</button>
</nav>
<div class="mt-auto flex flex-col gap-6 w-full">
<button class="group flex flex-col items-center gap-1.5 w-full relative opacity-60 hover:opacity-100 transition-all">
<span class="material-symbols-outlined text-[28px]">settings</span>
<span class="text-[10px] font-medium tracking-wide">Settings</span>
</button>
</div>
</aside>
<!-- Main Content Area -->
<div class="flex-1 flex flex-col h-full overflow-hidden relative">
<!-- Top App Bar -->
<header class="glass-header h-16 flex items-center justify-between px-6 z-20 shrink-0">
<div class="flex items-center gap-4">
<h1 class="text-white text-lg font-bold tracking-tight">Buddy The Underwriter</h1>
</div>
<!-- Tenant Selector -->
<button class="flex items-center gap-2 bg-[#282f39]/50 hover:bg-[#282f39] border border-white/10 rounded-full py-1.5 px-4 transition-colors">
<span class="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]"></span>
<span class="text-sm font-medium text-white">Old Glory Bank</span>
<span class="material-symbols-outlined text-sm text-gray-400">expand_more</span>
</button>
<div class="flex items-center gap-3">
<div class="flex items-center bg-[#282f39]/30 rounded-full px-3 h-9 border border-white/5 focus-within:border-primary/50 transition-colors w-64">
<span class="material-symbols-outlined text-[18px] text-gray-400">search</span>
<input class="bg-transparent border-none text-sm text-white placeholder-gray-500 focus:ring-0 w-full h-full p-0 pl-2" placeholder="Search deals, sponsors..." type="text"/>
<span class="text-xs text-gray-600 font-mono">⌘K</span>
</div>
<button class="w-9 h-9 rounded-full flex items-center justify-center hover:bg-white/10 text-gray-400 hover:text-white transition-colors">
<span class="material-symbols-outlined text-[20px]">notifications</span>
</button>
<button class="w-9 h-9 rounded-full flex items-center justify-center hover:bg-white/10 text-gray-400 hover:text-white transition-colors">
<span class="material-symbols-outlined text-[20px]">help</span>
</button>
<div class="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-500 to-blue-500 flex items-center justify-center text-xs font-bold border border-white/20 cursor-pointer">
                    JD
                </div>
</div>
</header>
<!-- Scrollable Workspace -->
<main class="flex-1 flex overflow-hidden">
<!-- Center Column: Pipeline -->
<div class="flex-1 overflow-y-auto px-6 py-6 pb-20">
<!-- Header Section -->
<div class="flex flex-col gap-5 mb-6">
<div class="flex justify-between items-start">
<div>
<h2 class="text-3xl font-bold tracking-tight text-white mb-1">Deals Command Bridge</h2>
<p class="text-gray-400 text-sm">Real-time credit posture across your pipeline</p>
</div>
<div class="flex gap-3">
<button class="h-9 px-4 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-sm font-medium text-white transition-colors flex items-center gap-2">
<span class="material-symbols-outlined text-[18px]">refresh</span>
                                Refresh
                            </button>
<button class="h-9 px-4 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-sm font-medium text-white transition-colors flex items-center gap-2">
<span class="material-symbols-outlined text-[18px]">ios_share</span>
                                Export
                            </button>
<button class="h-9 px-4 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-sm font-medium text-white transition-colors flex items-center gap-2">
<span class="material-symbols-outlined text-[18px]">link</span>
                                Request Link
                            </button>
<button class="h-9 px-5 rounded-full bg-primary hover:bg-primary-hover shadow-[0_0_15px_rgba(19,109,236,0.3)] text-sm font-bold text-white transition-all flex items-center gap-2">
<span class="material-symbols-outlined text-[20px]">add</span>
                                New Deal
                            </button>
</div>
</div>
<!-- System Status Strip -->
<div class="flex items-center gap-4 text-xs font-medium text-gray-400 bg-white/[0.02] border-y border-white/[0.05] py-2 px-1">
<span class="uppercase tracking-wider text-[10px] opacity-60 mr-2">System Status</span>
<div class="flex items-center gap-2 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
<span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                            Live OCR: Online
                        </div>
<div class="flex items-center gap-2 px-2 py-0.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400">
<span class="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></span>
                            Evidence: Streaming
                        </div>
<div class="flex items-center gap-2 px-2 py-0.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400">
<span class="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
                            Portal: Active
                        </div>
<div class="flex items-center gap-2 px-2 py-0.5 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-400">
<span class="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                            Queue: 3
                        </div>
</div>
</div>
<!-- KPI / Telemetry Strip -->
<div class="grid grid-cols-6 gap-3 mb-6">
<!-- KPI Card -->
<div class="glass-panel p-3 rounded-2xl flex flex-col justify-between h-24 relative overflow-hidden group hover:border-white/20 transition-all">
<div class="flex justify-between items-start z-10">
<span class="text-xs text-gray-400 font-medium truncate">Active Deals</span>
</div>
<div class="flex items-end justify-between z-10">
<span class="text-2xl font-bold text-white">42</span>
<span class="text-[10px] font-bold text-emerald-400 flex items-center bg-emerald-500/10 px-1.5 py-0.5 rounded">
<span class="material-symbols-outlined text-[10px] mr-0.5">trending_up</span> 12%
                            </span>
</div>
<!-- Sparkline -->
<svg class="absolute bottom-0 left-0 w-full h-12 text-emerald-500/10 z-0 sparkline" preserveaspectratio="none" viewbox="0 0 100 30">
<path d="M0 25 Q 20 28, 40 10 T 80 15 T 100 5 V 30 H 0 Z" fill="currentColor"></path>
<path d="M0 25 Q 20 28, 40 10 T 80 15 T 100 5" fill="none" stroke="rgba(16,185,129,0.3)" stroke-width="2"></path>
</svg>
</div>
<div class="glass-panel p-3 rounded-2xl flex flex-col justify-between h-24 relative overflow-hidden hover:border-white/20 transition-all">
<div class="flex justify-between items-start z-10">
<span class="text-xs text-gray-400 font-medium truncate">Needs Attention</span>
</div>
<div class="flex items-end justify-between z-10">
<span class="text-2xl font-bold text-white">5</span>
<span class="text-[10px] font-bold text-amber-400 flex items-center bg-amber-500/10 px-1.5 py-0.5 rounded">
                                +2
                            </span>
</div>
<svg class="absolute bottom-0 left-0 w-full h-12 text-amber-500/10 z-0 sparkline" preserveaspectratio="none" viewbox="0 0 100 30">
<path d="M0 20 Q 30 5, 50 20 T 100 10 V 30 H 0 Z" fill="currentColor"></path>
<path d="M0 20 Q 30 5, 50 20 T 100 10" fill="none" stroke="rgba(245, 158, 11, 0.3)" stroke-width="2"></path>
</svg>
</div>
<div class="glass-panel p-3 rounded-2xl flex flex-col justify-between h-24 relative overflow-hidden hover:border-white/20 transition-all">
<div class="flex justify-between items-start z-10">
<span class="text-xs text-gray-400 font-medium truncate">Missing Docs</span>
</div>
<div class="flex items-end justify-between z-10">
<span class="text-2xl font-bold text-white">12</span>
<span class="text-[10px] font-bold text-gray-400 flex items-center">
                                -3
                            </span>
</div>
<svg class="absolute bottom-0 left-0 w-full h-12 text-blue-500/10 z-0 sparkline" preserveaspectratio="none" viewbox="0 0 100 30">
<path d="M0 10 Q 50 25, 100 15 V 30 H 0 Z" fill="currentColor"></path>
<path d="M0 10 Q 50 25, 100 15" fill="none" stroke="rgba(59, 130, 246, 0.3)" stroke-width="2"></path>
</svg>
</div>
<div class="glass-panel p-3 rounded-2xl flex flex-col justify-between h-24 relative overflow-hidden hover:border-white/20 transition-all">
<div class="flex justify-between items-start z-10">
<span class="text-xs text-gray-400 font-medium truncate">Risk Flags</span>
</div>
<div class="flex items-end justify-between z-10">
<span class="text-2xl font-bold text-white">3</span>
<span class="text-[10px] font-bold text-rose-400 flex items-center bg-rose-500/10 px-1.5 py-0.5 rounded">
                                Critical
                            </span>
</div>
<svg class="absolute bottom-0 left-0 w-full h-12 text-rose-500/10 z-0 sparkline" preserveaspectratio="none" viewbox="0 0 100 30">
<path d="M0 28 L 30 25 L 60 10 L 100 5 V 30 H 0 Z" fill="currentColor"></path>
<path d="M0 28 L 30 25 L 60 10 L 100 5" fill="none" stroke="rgba(244, 63, 94, 0.3)" stroke-width="2"></path>
</svg>
</div>
<div class="glass-panel p-3 rounded-2xl flex flex-col justify-between h-24 relative overflow-hidden hover:border-white/20 transition-all">
<div class="flex justify-between items-start z-10">
<span class="text-xs text-gray-400 font-medium truncate">SLA Breaches</span>
</div>
<div class="flex items-end justify-between z-10">
<span class="text-2xl font-bold text-white">1</span>
<span class="text-[10px] font-bold text-emerald-400 flex items-center">
                                0%
                            </span>
</div>
<div class="absolute inset-0 bg-gradient-to-t from-red-500/5 to-transparent z-0"></div>
</div>
<div class="glass-panel p-3 rounded-2xl flex flex-col justify-between h-24 relative overflow-hidden hover:border-white/20 transition-all">
<div class="flex justify-between items-start z-10">
<span class="text-xs text-gray-400 font-medium truncate">New Uploads</span>
</div>
<div class="flex items-end justify-between z-10">
<span class="text-2xl font-bold text-white">28</span>
<span class="text-[10px] font-bold text-gray-400 flex items-center">
                                24h
                            </span>
</div>
<svg class="absolute bottom-0 left-0 w-full h-12 text-indigo-500/10 z-0 sparkline" preserveaspectratio="none" viewbox="0 0 100 30">
<path d="M0 25 Q 25 25, 50 10 T 100 20 V 30 H 0 Z" fill="currentColor"></path>
<path d="M0 25 Q 25 25, 50 10 T 100 20" fill="none" stroke="rgba(99, 102, 241, 0.3)" stroke-width="2"></path>
</svg>
</div>
</div>
<!-- Filters & Controls -->
<div class="flex justify-between items-center mb-4">
<div class="flex gap-2">
<div class="bg-white/5 border border-white/10 rounded-full px-4 py-1.5 flex items-center gap-2 cursor-pointer hover:bg-white/10 text-xs font-medium text-white transition-colors">
<span>Stage: All</span>
<span class="material-symbols-outlined text-[14px] opacity-70">expand_more</span>
</div>
<div class="bg-white/5 border border-white/10 rounded-full px-4 py-1.5 flex items-center gap-2 cursor-pointer hover:bg-white/10 text-xs font-medium text-white transition-colors">
<span>Risk: High</span>
<span class="material-symbols-outlined text-[14px] opacity-70">expand_more</span>
</div>
<div class="bg-white/5 border border-white/10 rounded-full px-4 py-1.5 flex items-center gap-2 cursor-pointer hover:bg-white/10 text-xs font-medium text-white transition-colors">
<span>Missing Docs</span>
<span class="material-symbols-outlined text-[14px] opacity-70">expand_more</span>
</div>
<div class="bg-white/5 border border-white/10 rounded-full px-4 py-1.5 flex items-center gap-2 cursor-pointer hover:bg-white/10 text-xs font-medium text-white transition-colors">
<span>Owner: Me</span>
<span class="material-symbols-outlined text-[14px] opacity-70">expand_more</span>
</div>
</div>
<div class="flex items-center gap-2 text-xs text-gray-400">
<span>Sort by:</span>
<span class="text-white cursor-pointer hover:underline">Last Updated</span>
<span class="material-symbols-outlined text-[14px]">arrow_downward</span>
</div>
</div>
<!-- Deals Table -->
<div class="glass-panel rounded-2xl overflow-hidden mb-10">
<div class="overflow-x-auto">
<table class="w-full text-left text-sm whitespace-nowrap">
<thead>
<tr class="bg-white/[0.03] border-b border-white/[0.08] text-gray-400 font-medium text-xs uppercase tracking-wider">
<th class="py-3 px-4 pl-6 font-semibold">Deal Name</th>
<th class="py-3 px-4 font-semibold">Stage</th>
<th class="py-3 px-4 font-semibold text-right">DSCR</th>
<th class="py-3 px-4 font-semibold text-right">LTV</th>
<th class="py-3 px-4 font-semibold text-right">NOI</th>
<th class="py-3 px-4 font-semibold text-right">Occ %</th>
<th class="py-3 px-4 font-semibold text-right">Score</th>
<th class="py-3 px-4 font-semibold text-center">Missing</th>
<th class="py-3 px-4 font-semibold text-center">Risk</th>
<th class="py-3 px-4 font-semibold">Next Action</th>
<th class="py-3 px-4 font-semibold text-right">Updated</th>
<th class="py-3 px-4 pr-6 font-semibold">Owner</th>
</tr>
</thead>
<tbody class="divide-y divide-white/[0.05]">
<!-- Row 1 -->
<tr class="table-row-hover group transition-colors relative cursor-pointer">
<td class="py-3 px-4 pl-6 relative">
<div class="absolute left-0 top-0 bottom-0 w-1 bg-amber-500"></div>
<div class="flex flex-col">
<span class="text-white font-semibold">Harbor Point Multifamily</span>
<span class="text-xs text-gray-500">Austin, TX • Greenwater Capital</span>
</div>
</td>
<td class="py-3 px-4">
<span class="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 text-xs border border-blue-500/30">Underwriting</span>
</td>
<td class="py-3 px-4 text-right font-mono text-white">1.25x</td>
<td class="py-3 px-4 text-right font-mono text-white">65%</td>
<td class="py-3 px-4 text-right font-mono text-gray-400">$1.2M</td>
<td class="py-3 px-4 text-right font-mono text-white">94%</td>
<td class="py-3 px-4 text-right font-mono text-emerald-400">780</td>
<td class="py-3 px-4 text-center">
<span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-rose-500/20 text-rose-400 text-xs font-bold border border-rose-500/30" title="Rent Roll, Tax Returns">2</span>
</td>
<td class="py-3 px-4 text-center">
<span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 text-xs font-bold border border-amber-500/30" title="Flood Zone">1</span>
</td>
<td class="py-3 px-4 text-gray-300">Verify Insurance</td>
<td class="py-3 px-4 text-right text-xs text-gray-500">2m ago</td>
<td class="py-3 px-4 pr-6 relative">
<div class="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-xs font-bold text-white border border-white/20">JD</div>
<!-- Hover Quick Actions -->
<div class="quick-actions absolute right-2 top-1/2 -translate-y-1/2 bg-[#1a1d24] rounded-full shadow-xl border border-white/10 flex items-center gap-1 px-1 py-1 opacity-0 transition-opacity pointer-events-none z-10">
<button class="p-1.5 rounded-full hover:bg-white/10 text-gray-400 hover:text-white" title="Open"><span class="material-symbols-outlined text-[18px]">open_in_new</span></button>
<button class="p-1.5 rounded-full hover:bg-white/10 text-gray-400 hover:text-white" title="Evidence"><span class="material-symbols-outlined text-[18px]">description</span></button>
<button class="p-1.5 rounded-full hover:bg-white/10 text-gray-400 hover:text-white" title="Request Docs"><span class="material-symbols-outlined text-[18px]">outgoing_mail</span></button>
<button class="p-1.5 rounded-full hover:bg-white/10 text-gray-400 hover:text-white" title="Share"><span class="material-symbols-outlined text-[18px]">share</span></button>
</div>
</td>
</tr>
<!-- Row 2 -->
<tr class="table-row-hover group transition-colors relative bg-white/[0.01]">
<td class="py-3 px-4 pl-6 relative">
<div class="absolute left-0 top-0 bottom-0 w-1 bg-emerald-500"></div>
<div class="flex flex-col">
<span class="text-white font-semibold">Oak Creek Industrial</span>
<span class="text-xs text-gray-500">Dallas, TX • T4 Logistics</span>
</div>
</td>
<td class="py-3 px-4">
<span class="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 text-xs border border-purple-500/30">Closing</span>
</td>
<td class="py-3 px-4 text-right font-mono text-emerald-400">1.45x</td>
<td class="py-3 px-4 text-right font-mono text-white">55%</td>
<td class="py-3 px-4 text-right font-mono text-gray-400">$850k</td>
<td class="py-3 px-4 text-right font-mono text-white">100%</td>
<td class="py-3 px-4 text-right font-mono text-emerald-400">810</td>
<td class="py-3 px-4 text-center">
<span class="material-symbols-outlined text-gray-600 text-[18px]">check</span>
</td>
<td class="py-3 px-4 text-center">
<span class="material-symbols-outlined text-gray-600 text-[18px]">check</span>
</td>
<td class="py-3 px-4 text-gray-300">Final Review</td>
<td class="py-3 px-4 text-right text-xs text-gray-500">45m ago</td>
<td class="py-3 px-4 pr-6">
<div class="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-xs font-bold text-white border border-white/20">AK</div>
</td>
</tr>
<!-- Row 3 -->
<tr class="table-row-hover group transition-colors relative">
<td class="py-3 px-4 pl-6 relative">
<div class="absolute left-0 top-0 bottom-0 w-1 bg-rose-500"></div>
<div class="flex flex-col">
<span class="text-white font-semibold">The View at Midtown</span>
<span class="text-xs text-gray-500">Atlanta, GA • Urban Core Dev</span>
</div>
</td>
<td class="py-3 px-4">
<span class="px-2 py-0.5 rounded-full bg-gray-500/20 text-gray-300 text-xs border border-gray-500/30">Initial Review</span>
</td>
<td class="py-3 px-4 text-right font-mono text-rose-400">0.95x</td>
<td class="py-3 px-4 text-right font-mono text-white">75%</td>
<td class="py-3 px-4 text-right font-mono text-gray-400">$2.4M</td>
<td class="py-3 px-4 text-right font-mono text-white">82%</td>
<td class="py-3 px-4 text-right font-mono text-amber-400">650</td>
<td class="py-3 px-4 text-center">
<span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-rose-500/20 text-rose-400 text-xs font-bold border border-rose-500/30">5</span>
</td>
<td class="py-3 px-4 text-center">
<span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-rose-500/20 text-rose-400 text-xs font-bold border border-rose-500/30">3</span>
</td>
<td class="py-3 px-4 text-gray-300">Request Financials</td>
<td class="py-3 px-4 text-right text-xs text-gray-500">1h ago</td>
<td class="py-3 px-4 pr-6">
<div class="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-xs font-bold text-white border border-white/20">MS</div>
</td>
</tr>
<!-- Row 4 -->
<tr class="table-row-hover group transition-colors relative bg-white/[0.01]">
<td class="py-3 px-4 pl-6 relative">
<div class="absolute left-0 top-0 bottom-0 w-1 bg-amber-500"></div>
<div class="flex flex-col">
<span class="text-white font-semibold">Lakeside Offices</span>
<span class="text-xs text-gray-500">Chicago, IL • Lakefront Partners</span>
</div>
</td>
<td class="py-3 px-4">
<span class="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 text-xs border border-blue-500/30">Underwriting</span>
</td>
<td class="py-3 px-4 text-right font-mono text-white">1.15x</td>
<td class="py-3 px-4 text-right font-mono text-white">60%</td>
<td class="py-3 px-4 text-right font-mono text-gray-400">$600k</td>
<td class="py-3 px-4 text-right font-mono text-white">88%</td>
<td class="py-3 px-4 text-right font-mono text-white">720</td>
<td class="py-3 px-4 text-center">
<span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-rose-500/20 text-rose-400 text-xs font-bold border border-rose-500/30">1</span>
</td>
<td class="py-3 px-4 text-center">
<span class="material-symbols-outlined text-gray-600 text-[18px]">check</span>
</td>
<td class="py-3 px-4 text-gray-300">Clarify Expenses</td>
<td class="py-3 px-4 text-right text-xs text-gray-500">3h ago</td>
<td class="py-3 px-4 pr-6">
<div class="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-xs font-bold text-white border border-white/20">JD</div>
</td>
</tr>
<!-- Row 5 -->
<tr class="table-row-hover group transition-colors relative">
<td class="py-3 px-4 pl-6 relative">
<div class="absolute left-0 top-0 bottom-0 w-1 bg-emerald-500"></div>
<div class="flex flex-col">
<span class="text-white font-semibold">Westside Warehouses</span>
<span class="text-xs text-gray-500">Phoenix, AZ • Desert Rock</span>
</div>
</td>
<td class="py-3 px-4">
<span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-xs border border-emerald-500/30">Approved</span>
</td>
<td class="py-3 px-4 text-right font-mono text-emerald-400">1.60x</td>
<td class="py-3 px-4 text-right font-mono text-white">50%</td>
<td class="py-3 px-4 text-right font-mono text-gray-400">$1.1M</td>
<td class="py-3 px-4 text-right font-mono text-white">98%</td>
<td class="py-3 px-4 text-right font-mono text-emerald-400">790</td>
<td class="py-3 px-4 text-center">
<span class="material-symbols-outlined text-gray-600 text-[18px]">check</span>
</td>
<td class="py-3 px-4 text-center">
<span class="material-symbols-outlined text-gray-600 text-[18px]">check</span>
</td>
<td class="py-3 px-4 text-gray-300">Prepare Letter</td>
<td class="py-3 px-4 text-right text-xs text-gray-500">5h ago</td>
<td class="py-3 px-4 pr-6">
<div class="w-8 h-8 rounded-full bg-teal-600 flex items-center justify-center text-xs font-bold text-white border border-white/20">RT</div>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<!-- Right Column: Intelligence Stack -->
<div class="w-80 flex-shrink-0 border-l border-glass-border bg-[#0f1115]/50 backdrop-blur-sm p-4 flex flex-col gap-4 overflow-y-auto">
<!-- Card 1: Now Acting On -->
<div class="glass-panel p-4 rounded-2xl border-primary/30 relative overflow-hidden group">
<div class="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
<span class="material-symbols-outlined text-6xl text-primary">target</span>
</div>
<div class="flex flex-col gap-2 relative z-10">
<div class="text-xs font-bold text-primary uppercase tracking-wider flex items-center gap-1">
<span class="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
                            Now Acting On
                        </div>
<h3 class="font-bold text-white text-lg leading-tight">Harbor Point Multifamily</h3>
<p class="text-xs text-gray-400">Refi • $12.5M • Austin, TX</p>
<button class="mt-2 w-full bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30 rounded-full py-2 text-sm font-semibold transition-colors">
                            Resume Underwriting
                        </button>
</div>
</div>
<!-- Card 2: Live Intelligence -->
<div class="glass-panel p-4 rounded-2xl flex flex-col gap-3">
<div class="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
<span class="material-symbols-outlined text-[16px]">rss_feed</span>
                        Live Intelligence
                    </div>
<div class="flex gap-3 items-start border-l-2 border-blue-500 pl-3 py-1">
<div class="flex flex-col gap-0.5">
<p class="text-sm text-gray-200 leading-snug">New <span class="text-white font-medium">Rent Roll</span> uploaded for Harbor Point.</p>
<span class="text-[10px] text-gray-500">2m ago • Auto-detected</span>
</div>
</div>
<div class="flex gap-3 items-start border-l-2 border-purple-500 pl-3 py-1">
<div class="flex flex-col gap-0.5">
<p class="text-sm text-gray-200 leading-snug">Sponsor credit score updated: <span class="text-emerald-400 font-medium">780 (+15)</span>.</p>
<span class="text-[10px] text-gray-500">15m ago • Experian</span>
</div>
</div>
</div>
<!-- Card 3: Conditions & Missing Docs -->
<div class="glass-panel p-4 rounded-2xl flex flex-col gap-3">
<div class="flex justify-between items-center">
<div class="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
<span class="material-symbols-outlined text-[16px]">checklist</span>
                            Conditions
                        </div>
<span class="bg-rose-500/20 text-rose-400 text-[10px] font-bold px-1.5 py-0.5 rounded">2 Critical</span>
</div>
<div class="space-y-2">
<div class="flex items-center justify-between p-2 rounded-lg bg-white/5 border border-white/5">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-rose-400 text-[18px]">error</span>
<span class="text-xs text-gray-300">2023 Tax Returns</span>
</div>
<span class="text-[10px] text-gray-500 bg-black/20 px-1.5 rounded">Required</span>
</div>
<div class="flex items-center justify-between p-2 rounded-lg bg-white/5 border border-white/5">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-amber-400 text-[18px]">warning</span>
<span class="text-xs text-gray-300">Insurance Cert</span>
</div>
<span class="text-[10px] text-gray-500 bg-black/20 px-1.5 rounded">Expiring</span>
</div>
</div>
<button class="w-full text-center text-xs text-primary font-medium hover:text-white transition-colors py-1">Send Request Bundle</button>
</div>
<!-- Card 4: Next Best Action -->
<div class="glass-panel p-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/5 relative overflow-hidden">
<div class="absolute -right-4 -top-4 w-20 h-20 bg-emerald-500/20 rounded-full blur-xl"></div>
<div class="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2 mb-2">
<span class="material-symbols-outlined text-[16px]">lightbulb</span>
                        Recommendation
                    </div>
<p class="text-sm text-gray-200 mb-3">DSCR of 1.25x exceeds guidelines for this asset class. Request borrower explanation or restructure.</p>
<div class="flex gap-2">
<button class="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full py-1.5 text-xs font-bold transition-colors">
                            Generate Link
                        </button>
<button class="flex-1 bg-white/10 hover:bg-white/20 text-white rounded-full py-1.5 text-xs font-medium transition-colors">
                            Assign Analyst
                        </button>
</div>
</div>
</div>
</main>
</div>`;

export default function Page() {
  return (
    <StitchFrame
      title={TITLE}
      fontLinks={FONT_LINKS}
      tailwindCdnSrc={TAILWIND_CDN}
      tailwindConfigJs={TAILWIND_CONFIG_JS}
      styles={STYLES}
      bodyHtml={BODY_HTML}
    />
  );
}
