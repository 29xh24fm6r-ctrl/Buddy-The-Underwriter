export default function DocumentsPage(){ return <div className="p-8 text-white">Documents (stub)</div>; }
