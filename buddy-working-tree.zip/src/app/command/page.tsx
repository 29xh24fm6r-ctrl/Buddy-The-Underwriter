export default function CommandPage() {
  return <div className="p-8 text-white">Command (stub)</div>;
}
