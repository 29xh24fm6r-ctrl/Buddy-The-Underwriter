import StitchFrame from "@/components/stitch/StitchFrame";

const TITLE = "Buddy - Pipeline Analytics Command Center";
const FONT_LINKS: string[] = [];
const TAILWIND_CDN = "https://cdn.tailwindcss.com?plugins=forms,container-queries";
const TAILWIND_CONFIG_JS = `tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#136dec",
                        "primary-dark": "#0d4eb0",
                        "background-light": "#f6f7f8",
                        "background-dark": "#0f1218", /* Deep charcoal/almost black */
                        "surface-dark": "#1a1f29", /* Panel background */
                        "surface-darker": "#141820", /* Nested darker background */
                        "border-dark": "#2a3241",
                        "text-secondary": "#94a3b8",
                        "success": "#10b981",
                        "warning": "#f59e0b",
                        "danger": "#ef4444",
                    },
                    fontFamily: {
                        "display": ["Inter", "sans-serif"],
                        "mono": ["JetBrains Mono", "monospace"],
                    },
                    fontSize: {
                        'xxs': '0.65rem',
                    },
                    borderRadius: {
                        "DEFAULT": "0.125rem",
                        "sm": "0.125rem",
                        "md": "0.25rem",
                        "lg": "0.375rem",
                        "xl": "0.5rem",
                        "full": "9999px",
                    },
                },
            },
        }`;
const STYLES = [
  "/* Custom scrollbar for terminal feel */\n        ::-webkit-scrollbar {\n            width: 8px;\n            height: 8px;\n        }\n        ::-webkit-scrollbar-track {\n            background: #141820; \n        }\n        ::-webkit-scrollbar-thumb {\n            background: #2a3241; \n            border-radius: 4px;\n        }\n        ::-webkit-scrollbar-thumb:hover {\n            background: #3b4658; \n        }\n        .glass-panel {\n            background: rgba(26, 31, 41, 0.95);\n            border: 1px solid #2a3241;\n            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);\n        }\n        .data-table th {\n            text-transform: uppercase;\n            font-size: 0.7rem;\n            letter-spacing: 0.05em;\n            color: #94a3b8;\n            font-weight: 600;\n        }\n        .data-table td {\n            font-size: 0.8rem;\n        }\n        /* Chart mocks */\n        .bar-segment { transition: all 0.2s; }\n        .bar-segment:hover { opacity: 0.8; }"
];
const BODY_HTML = `<!-- Global Header -->
<header class="sticky top-0 z-50 flex items-center justify-between whitespace-nowrap border-b border-solid border-border-dark bg-[#111418] px-6 py-2.5 shadow-sm">
<div class="flex items-center gap-6">
<div class="flex items-center gap-3 text-white">
<div class="size-6 text-primary">
<span class="material-symbols-outlined text-[28px] leading-none">token</span>
</div>
<h2 class="text-white text-lg font-bold tracking-tight">Buddy</h2>
</div>
<nav class="hidden xl:flex items-center gap-6 border-l border-border-dark pl-6 h-6">
<a class="text-text-secondary hover:text-white text-xs font-medium uppercase tracking-wide transition-colors" href="#">Deals</a>
<a class="text-text-secondary hover:text-white text-xs font-medium uppercase tracking-wide transition-colors" href="#">Intake</a>
<a class="text-text-secondary hover:text-white text-xs font-medium uppercase tracking-wide transition-colors" href="#">Portfolio</a>
<a class="text-text-secondary hover:text-white text-xs font-medium uppercase tracking-wide transition-colors" href="#">Committee</a>
<a class="text-text-secondary hover:text-white text-xs font-medium uppercase tracking-wide transition-colors" href="#">Reporting</a>
<a class="text-primary text-xs font-bold uppercase tracking-wide" href="#">Analytics</a>
<a class="text-text-secondary hover:text-white text-xs font-medium uppercase tracking-wide transition-colors" href="#">Admin</a>
</nav>
</div>
<div class="flex items-center justify-end gap-4">
<div class="relative hidden lg:block">
<span class="absolute inset-y-0 left-0 flex items-center pl-3 text-text-secondary">
<span class="material-symbols-outlined text-[18px]">search</span>
</span>
<input class="w-64 bg-surface-darker border border-border-dark rounded-md py-1.5 pl-9 pr-3 text-xs text-white placeholder-text-secondary focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary" placeholder="Search deals, sponsors, or metrics..."/>
</div>
<button class="relative text-text-secondary hover:text-white transition-colors">
<span class="material-symbols-outlined text-[20px]">notifications</span>
<span class="absolute top-0 right-0 size-2 bg-danger rounded-full border-2 border-[#111418]"></span>
</button>
<div class="h-8 w-8 rounded bg-gradient-to-br from-primary to-blue-700 flex items-center justify-center text-xs font-bold text-white border border-border-dark" data-alt="User Avatar">
                JD
            </div>
</div>
</header>
<!-- Executive Control Bar -->
<div class="sticky top-[57px] z-40 flex items-center justify-between gap-4 border-b border-border-dark bg-surface-dark px-6 py-3">
<div class="flex items-center gap-3 overflow-x-auto no-scrollbar">
<!-- Date Picker -->
<button class="flex items-center gap-2 bg-surface-darker border border-border-dark rounded px-3 py-1.5 hover:border-primary/50 transition-colors group">
<span class="material-symbols-outlined text-text-secondary text-[16px] group-hover:text-primary">calendar_today</span>
<span class="text-xs font-medium text-white">Last 30 Days</span>
<span class="material-symbols-outlined text-text-secondary text-[16px]">arrow_drop_down</span>
</button>
<div class="h-6 w-px bg-border-dark mx-1"></div>
<!-- Filters -->
<div class="flex gap-2">
<button class="flex items-center gap-1.5 bg-surface-darker border border-border-dark rounded px-3 py-1.5 hover:bg-border-dark/30 transition-colors">
<span class="text-xs text-text-secondary">Region:</span>
<span class="text-xs font-medium text-white">All</span>
<span class="material-symbols-outlined text-text-secondary text-[14px]">expand_more</span>
</button>
<button class="flex items-center gap-1.5 bg-surface-darker border border-border-dark rounded px-3 py-1.5 hover:bg-border-dark/30 transition-colors">
<span class="text-xs text-text-secondary">Asset:</span>
<span class="text-xs font-medium text-white">All</span>
<span class="material-symbols-outlined text-text-secondary text-[14px]">expand_more</span>
</button>
<button class="flex items-center gap-1.5 bg-surface-darker border border-border-dark rounded px-3 py-1.5 hover:bg-border-dark/30 transition-colors">
<span class="text-xs text-text-secondary">Size:</span>
<span class="text-xs font-medium text-white">&gt; $10M</span>
<span class="material-symbols-outlined text-text-secondary text-[14px]">expand_more</span>
</button>
<button class="flex items-center gap-1.5 bg-surface-darker border border-border-dark rounded px-3 py-1.5 hover:bg-border-dark/30 transition-colors">
<span class="text-xs text-text-secondary">Show:</span>
<span class="text-xs font-medium text-white">Pipeline</span>
<span class="material-symbols-outlined text-text-secondary text-[14px]">expand_more</span>
</button>
</div>
</div>
<!-- Actions -->
<div class="flex items-center gap-3 shrink-0">
<button class="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-primary hover:text-white transition-colors">
<span class="material-symbols-outlined text-[16px]">picture_as_pdf</span>
                Export Board Pack
            </button>
<button class="flex items-center gap-2 px-3 py-1.5 bg-primary hover:bg-primary-dark text-white text-xs font-semibold rounded shadow-sm transition-colors border border-primary/50">
<span class="material-symbols-outlined text-[16px]">download</span>
                Export CSV
            </button>
</div>
</div>
<!-- Main Content Grid -->
<main class="flex-1 p-6 grid gap-6 content-start">
<!-- KPI Strip -->
<div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
<!-- KPI Tile 1 -->
<div class="glass-panel p-3 rounded flex flex-col justify-between h-24">
<div class="text-text-secondary text-xxs uppercase tracking-wider font-semibold">New Submissions (30d)</div>
<div class="flex items-end justify-between">
<div class="text-2xl font-bold text-white font-mono">142</div>
<div class="text-success text-xs font-mono font-medium flex items-center">
<span class="material-symbols-outlined text-[14px]">trending_up</span> 12%
                    </div>
</div>
</div>
<!-- KPI Tile 2 -->
<div class="glass-panel p-3 rounded flex flex-col justify-between h-24">
<div class="text-text-secondary text-xxs uppercase tracking-wider font-semibold">Active Pipeline</div>
<div class="flex items-end justify-between">
<div class="text-2xl font-bold text-white font-mono">$1.24B</div>
<div class="text-success text-xs font-mono font-medium flex items-center">
<span class="material-symbols-outlined text-[14px]">trending_up</span> 5%
                    </div>
</div>
</div>
<!-- KPI Tile 3 -->
<div class="glass-panel p-3 rounded flex flex-col justify-between h-24">
<div class="text-text-secondary text-xxs uppercase tracking-wider font-semibold">Avg Decision Time</div>
<div class="flex items-end justify-between">
<div class="text-2xl font-bold text-white font-mono">18d</div>
<div class="text-success text-xs font-mono font-medium flex items-center">
<span class="material-symbols-outlined text-[14px]">trending_down</span> -2d
                    </div>
</div>
</div>
<!-- KPI Tile 4 -->
<div class="glass-panel p-3 rounded flex flex-col justify-between h-24">
<div class="text-text-secondary text-xxs uppercase tracking-wider font-semibold">Approval Rate</div>
<div class="flex items-end justify-between">
<div class="text-2xl font-bold text-white font-mono">62%</div>
<div class="text-warning text-xs font-mono font-medium flex items-center">
<span class="material-symbols-outlined text-[14px]">trending_flat</span> 0%
                    </div>
</div>
</div>
<!-- KPI Tile 5 -->
<div class="glass-panel p-3 rounded flex flex-col justify-between h-24">
<div class="text-text-secondary text-xxs uppercase tracking-wider font-semibold">Decline Rate</div>
<div class="flex items-end justify-between">
<div class="text-2xl font-bold text-white font-mono">15%</div>
<div class="text-success text-xs font-mono font-medium flex items-center">
<span class="material-symbols-outlined text-[14px]">trending_down</span> -1%
                    </div>
</div>
</div>
<!-- KPI Tile 6 -->
<div class="glass-panel p-3 rounded flex flex-col justify-between h-24">
<div class="text-text-secondary text-xxs uppercase tracking-wider font-semibold">Exceptions / Deal</div>
<div class="flex items-end justify-between">
<div class="text-2xl font-bold text-white font-mono">1.2</div>
<div class="text-text-secondary text-xs font-mono font-medium flex items-center">
                        -
                    </div>
</div>
</div>
<!-- KPI Tile 7 -->
<div class="glass-panel p-3 rounded flex flex-col justify-between h-24">
<div class="text-text-secondary text-xxs uppercase tracking-wider font-semibold">Est. Spread Income</div>
<div class="flex items-end justify-between">
<div class="text-2xl font-bold text-white font-mono">$14.5M</div>
<div class="text-success text-xs font-mono font-medium flex items-center">
<span class="material-symbols-outlined text-[14px]">trending_up</span> 8%
                    </div>
</div>
</div>
<!-- KPI Tile 8 -->
<div class="glass-panel p-3 rounded flex flex-col justify-between h-24">
<div class="text-text-secondary text-xxs uppercase tracking-wider font-semibold">Fees Booked (30d)</div>
<div class="flex items-end justify-between">
<div class="text-2xl font-bold text-white font-mono">$850k</div>
<div class="text-success text-xs font-mono font-medium flex items-center">
<span class="material-symbols-outlined text-[14px]">trending_up</span> 15%
                    </div>
</div>
</div>
</div>
<!-- Middle Section: 2 Columns -->
<div class="grid grid-cols-12 gap-6">
<!-- LEFT COLUMN: Pipeline Flow + Velocity -->
<div class="col-span-12 lg:col-span-7 flex flex-col gap-6">
<!-- Panel Header -->
<div class="flex items-center justify-between pb-1 border-b border-border-dark">
<h3 class="text-white text-sm font-bold uppercase tracking-wide flex items-center gap-2">
<span class="material-symbols-outlined text-primary text-[18px]">water</span>
                        Pipeline Flow + Velocity
                    </h3>
</div>
<!-- Pipeline Funnel -->
<div class="glass-panel rounded p-5">
<div class="flex justify-between items-center mb-4">
<span class="text-xs font-semibold text-text-secondary uppercase">Pipeline by Stage</span>
<div class="flex gap-2 text-xxs">
<span class="flex items-center gap-1"><span class="size-2 rounded-full bg-blue-500"></span>Healthy</span>
<span class="flex items-center gap-1"><span class="size-2 rounded-full bg-warning"></span>Stuck &gt; 10d</span>
</div>
</div>
<div class="space-y-4">
<!-- Stage Row 1 -->
<div class="grid grid-cols-12 gap-4 items-center group">
<div class="col-span-3 text-xs font-medium text-white">New Submission</div>
<div class="col-span-7 h-6 flex rounded overflow-hidden bg-surface-darker border border-border-dark">
<div class="bg-blue-600 h-full w-[85%] relative group-hover:bg-blue-500 transition-colors"></div>
<div class="bg-warning h-full w-[15%] relative"></div>
</div>
<div class="col-span-2 text-right font-mono text-xs text-text-secondary">42 ($480M)</div>
</div>
<!-- Stage Row 2 -->
<div class="grid grid-cols-12 gap-4 items-center group">
<div class="col-span-3 text-xs font-medium text-white">Underwriting</div>
<div class="col-span-7 h-6 flex rounded overflow-hidden bg-surface-darker border border-border-dark">
<div class="bg-blue-600 h-full w-[70%] group-hover:bg-blue-500 transition-colors"></div>
<div class="bg-warning h-full w-[30%]"></div>
</div>
<div class="col-span-2 text-right font-mono text-xs text-text-secondary">28 ($310M)</div>
</div>
<!-- Stage Row 3 -->
<div class="grid grid-cols-12 gap-4 items-center group">
<div class="col-span-3 text-xs font-medium text-white">Credit Review</div>
<div class="col-span-7 h-6 flex rounded overflow-hidden bg-surface-darker border border-border-dark">
<div class="bg-blue-600 h-full w-[90%] group-hover:bg-blue-500 transition-colors"></div>
<div class="bg-warning h-full w-[10%]"></div>
</div>
<div class="col-span-2 text-right font-mono text-xs text-text-secondary">15 ($220M)</div>
</div>
<!-- Stage Row 4 -->
<div class="grid grid-cols-12 gap-4 items-center group">
<div class="col-span-3 text-xs font-medium text-white">Committee Appr.</div>
<div class="col-span-7 h-6 flex rounded overflow-hidden bg-surface-darker border border-border-dark">
<div class="bg-blue-600 h-full w-[95%] group-hover:bg-blue-500 transition-colors"></div>
<div class="bg-warning h-full w-[5%]"></div>
</div>
<div class="col-span-2 text-right font-mono text-xs text-text-secondary">8 ($140M)</div>
</div>
</div>
</div>
<div class="grid grid-cols-2 gap-6">
<!-- Velocity Heatmap -->
<div class="glass-panel rounded p-0 overflow-hidden">
<div class="px-4 py-3 border-b border-border-dark bg-surface-darker">
<h4 class="text-xs font-bold text-white uppercase">Time-in-Stage Velocity</h4>
</div>
<table class="w-full text-left data-table">
<thead class="bg-surface-darker border-b border-border-dark">
<tr>
<th class="px-4 py-2">Stage</th>
<th class="px-4 py-2 text-right">Median</th>
<th class="px-4 py-2 text-right">P90</th>
</tr>
</thead>
<tbody class="divide-y divide-border-dark text-text-secondary">
<tr>
<td class="px-4 py-2 font-medium text-white">New</td>
<td class="px-4 py-2 text-right font-mono">2d</td>
<td class="px-4 py-2 text-right font-mono text-success">4d</td>
</tr>
<tr>
<td class="px-4 py-2 font-medium text-white">Underwriting</td>
<td class="px-4 py-2 text-right font-mono">12d</td>
<td class="px-4 py-2 text-right font-mono text-danger font-bold">28d</td>
</tr>
<tr>
<td class="px-4 py-2 font-medium text-white">Credit</td>
<td class="px-4 py-2 text-right font-mono">5d</td>
<td class="px-4 py-2 text-right font-mono text-warning">14d</td>
</tr>
<tr>
<td class="px-4 py-2 font-medium text-white">Closing</td>
<td class="px-4 py-2 text-right font-mono">25d</td>
<td class="px-4 py-2 text-right font-mono text-text-secondary">35d</td>
</tr>
</tbody>
</table>
</div>
<!-- Top Stuck Deals -->
<div class="glass-panel rounded p-0 overflow-hidden col-span-2 lg:col-span-1">
<div class="px-4 py-3 border-b border-border-dark bg-surface-darker flex justify-between items-center">
<h4 class="text-xs font-bold text-white uppercase">Critical Bottlenecks</h4>
<span class="text-xxs text-warning bg-warning/10 px-2 py-0.5 rounded border border-warning/20">5 Actionable</span>
</div>
<table class="w-full text-left data-table">
<thead class="bg-surface-darker border-b border-border-dark">
<tr>
<th class="px-4 py-2">Deal</th>
<th class="px-4 py-2">Stage</th>
<th class="px-4 py-2 text-right">Days</th>
</tr>
</thead>
<tbody class="divide-y divide-border-dark text-text-secondary">
<tr class="hover:bg-surface-darker transition-colors cursor-pointer">
<td class="px-4 py-2">
<div class="text-white font-medium text-xs">Project Helios</div>
<div class="text-[10px]">Indus. • Austin</div>
</td>
<td class="px-4 py-2 text-xs">Credit</td>
<td class="px-4 py-2 text-right font-mono text-danger font-bold">45</td>
</tr>
<tr class="hover:bg-surface-darker transition-colors cursor-pointer">
<td class="px-4 py-2">
<div class="text-white font-medium text-xs">Metro North</div>
<div class="text-[10px]">Office • NYC</div>
</td>
<td class="px-4 py-2 text-xs">UW</td>
<td class="px-4 py-2 text-right font-mono text-warning font-bold">22</td>
</tr>
<tr class="hover:bg-surface-darker transition-colors cursor-pointer">
<td class="px-4 py-2">
<div class="text-white font-medium text-xs">Lakeside Apts</div>
<div class="text-[10px]">MF • Tampa</div>
</td>
<td class="px-4 py-2 text-xs">Legal</td>
<td class="px-4 py-2 text-right font-mono text-warning font-bold">18</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<!-- RIGHT COLUMN: Risk Mix + Profitability -->
<div class="col-span-12 lg:col-span-5 flex flex-col gap-6">
<!-- Panel Header -->
<div class="flex items-center justify-between pb-1 border-b border-border-dark">
<h3 class="text-white text-sm font-bold uppercase tracking-wide flex items-center gap-2">
<span class="material-symbols-outlined text-primary text-[18px]">analytics</span>
                        Risk &amp; Profitability
                    </h3>
</div>
<!-- Profitability Cockpit -->
<div class="glass-panel rounded p-5 relative overflow-hidden group">
<div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
<span class="material-symbols-outlined text-[80px]">attach_money</span>
</div>
<div class="flex justify-between items-start mb-4 relative z-10">
<h4 class="text-xs font-bold text-white uppercase">Annualized Profitability</h4>
<div class="flex bg-surface-darker p-0.5 rounded border border-border-dark">
<button class="px-2 py-0.5 text-xxs font-medium rounded text-text-secondary hover:text-white">Rate -50</button>
<button class="px-2 py-0.5 text-xxs font-bold rounded bg-primary text-white shadow-sm">Base</button>
<button class="px-2 py-0.5 text-xxs font-medium rounded text-text-secondary hover:text-white">Rate +50</button>
</div>
</div>
<div class="grid grid-cols-2 gap-4 relative z-10">
<div>
<div class="text-text-secondary text-xxs mb-1">W. Avg Spread</div>
<div class="text-xl font-bold text-white font-mono">345 bps</div>
</div>
<div>
<div class="text-text-secondary text-xxs mb-1">W. Avg All-in Coupon</div>
<div class="text-xl font-bold text-white font-mono">7.85%</div>
</div>
<div class="col-span-2 h-px bg-border-dark my-1"></div>
<div>
<div class="text-text-secondary text-xxs mb-1">Exp. Annual Interest</div>
<div class="text-base font-bold text-success font-mono">$18.2M</div>
</div>
<div>
<div class="text-text-secondary text-xxs mb-1">Exp. Origination Fees</div>
<div class="text-base font-bold text-white font-mono">$1.4M</div>
</div>
<div class="col-span-2 pt-2">
<div class="flex justify-between items-end">
<span class="text-text-secondary text-xs font-medium">Expected ROE Proxy</span>
<span class="text-lg font-bold text-primary font-mono">14.2%</span>
</div>
<div class="w-full bg-surface-darker rounded-full h-1.5 mt-1">
<div class="bg-primary h-1.5 rounded-full w-[70%]"></div>
</div>
</div>
</div>
</div>
<!-- Concentration & Risk Grid -->
<div class="grid grid-cols-2 gap-4 flex-1">
<!-- Concentration -->
<div class="glass-panel rounded p-4">
<h4 class="text-xs font-bold text-white uppercase mb-3">Concentration</h4>
<div class="space-y-3">
<div>
<div class="flex justify-between text-xs mb-1">
<span class="text-text-secondary">Industrial</span>
<span class="text-white font-mono">45%</span>
</div>
<div class="w-full bg-surface-darker h-1 rounded-full"><div class="bg-indigo-500 h-1 rounded-full w-[45%]"></div></div>
</div>
<div>
<div class="flex justify-between text-xs mb-1">
<span class="text-text-secondary">Multifamily</span>
<span class="text-white font-mono">30%</span>
</div>
<div class="w-full bg-surface-darker h-1 rounded-full"><div class="bg-indigo-500 h-1 rounded-full w-[30%]"></div></div>
</div>
<div>
<div class="flex justify-between text-xs mb-1">
<span class="text-text-secondary">Office</span>
<span class="text-white font-mono text-warning">15%</span>
</div>
<div class="w-full bg-surface-darker h-1 rounded-full"><div class="bg-warning h-1 rounded-full w-[15%]"></div></div>
</div>
</div>
<div class="mt-4 pt-3 border-t border-border-dark">
<div class="flex items-center gap-2 mb-2">
<span class="material-symbols-outlined text-text-secondary text-[14px]">public</span>
<span class="text-xs font-semibold text-white">Top Exposure</span>
</div>
<div class="flex flex-wrap gap-2">
<span class="bg-surface-darker text-text-secondary text-xxs px-2 py-1 rounded border border-border-dark font-mono">TX: 22%</span>
<span class="bg-surface-darker text-text-secondary text-xxs px-2 py-1 rounded border border-border-dark font-mono">FL: 18%</span>
<span class="bg-surface-darker text-text-secondary text-xxs px-2 py-1 rounded border border-border-dark font-mono">NY: 12%</span>
</div>
</div>
</div>
<!-- Risk Distribution -->
<div class="glass-panel rounded p-4">
<h4 class="text-xs font-bold text-white uppercase mb-3">Risk Ratings</h4>
<div class="flex items-end gap-1 h-24 mb-2">
<!-- Bar Chart Simulation -->
<div class="flex-1 bg-surface-darker rounded-t relative group">
<div class="absolute bottom-0 w-full bg-success/80 group-hover:bg-success rounded-t transition-all" style="height: 10%"></div>
</div>
<div class="flex-1 bg-surface-darker rounded-t relative group">
<div class="absolute bottom-0 w-full bg-success/80 group-hover:bg-success rounded-t transition-all" style="height: 30%"></div>
</div>
<div class="flex-1 bg-surface-darker rounded-t relative group">
<div class="absolute bottom-0 w-full bg-success/80 group-hover:bg-success rounded-t transition-all" style="height: 60%"></div>
</div>
<div class="flex-1 bg-surface-darker rounded-t relative group">
<div class="absolute bottom-0 w-full bg-blue-500/80 group-hover:bg-blue-500 rounded-t transition-all" style="height: 85%"></div>
</div>
<div class="flex-1 bg-surface-darker rounded-t relative group">
<div class="absolute bottom-0 w-full bg-blue-500/80 group-hover:bg-blue-500 rounded-t transition-all" style="height: 40%"></div>
</div>
<div class="flex-1 bg-surface-darker rounded-t relative group">
<div class="absolute bottom-0 w-full bg-warning/80 group-hover:bg-warning rounded-t transition-all" style="height: 25%"></div>
</div>
<div class="flex-1 bg-surface-darker rounded-t relative group">
<div class="absolute bottom-0 w-full bg-danger/80 group-hover:bg-danger rounded-t transition-all" style="height: 10%"></div>
</div>
</div>
<div class="flex justify-between text-xxs text-text-secondary font-mono px-1">
<span>1</span>
<span>4</span>
<span>7</span>
<span>10</span>
</div>
<div class="mt-4 flex items-center gap-2">
<div class="size-2 rounded-full bg-blue-500"></div>
<div class="text-xs text-text-secondary">Avg Rating: <span class="text-white font-mono font-bold">4.2</span></div>
</div>
</div>
</div>
</div>
</div>
<!-- Bottom Row: Governance & Exceptions -->
<div class="mt-0"> <!-- Grid gap handled by parent -->
<!-- Panel Header -->
<div class="flex items-center justify-between pb-1 mb-4 border-b border-border-dark">
<h3 class="text-white text-sm font-bold uppercase tracking-wide flex items-center gap-2">
<span class="material-symbols-outlined text-primary text-[18px]">gavel</span>
                    Governance &amp; Exceptions
                </h3>
</div>
<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
<!-- Exceptions Trend -->
<div class="glass-panel rounded p-5">
<div class="flex justify-between items-center mb-4">
<h4 class="text-xs font-bold text-white uppercase">Exceptions Trend (12w)</h4>
<div class="flex gap-1">
<span class="px-2 py-0.5 rounded-full bg-surface-darker border border-border-dark text-xxs text-text-secondary">LTV</span>
<span class="px-2 py-0.5 rounded-full bg-primary/20 border border-primary/30 text-xxs text-primary font-medium">DSCR</span>
</div>
</div>
<!-- Mock Line Chart -->
<div class="h-32 w-full relative border-l border-b border-border-dark">
<!-- Grid lines -->
<div class="absolute top-[25%] left-0 right-0 h-px bg-border-dark/30 border-dashed"></div>
<div class="absolute top-[50%] left-0 right-0 h-px bg-border-dark/30 border-dashed"></div>
<div class="absolute top-[75%] left-0 right-0 h-px bg-border-dark/30 border-dashed"></div>
<!-- The Line (SVG) -->
<svg class="absolute inset-0 h-full w-full overflow-visible" preserveaspectratio="none">
<path d="M0,100 C20,90 40,95 60,70 C80,45 100,50 120,60 C140,70 160,40 180,30 C200,20 220,25 240,40 C260,55 280,35 300,45 C320,55 340,60 360,50" fill="none" stroke="#ef4444" stroke-width="2" vector-effect="non-scaling-stroke"></path>
<path class="opacity-50" d="M0,80 C20,70 40,75 60,60 C80,45 100,40 120,50 C140,60 160,30 180,20 C200,10 220,15 240,30 C260,45 280,25 300,35 C320,45 340,50 360,40" fill="none" stroke="#10b981" stroke-dasharray="4" stroke-width="2" vector-effect="non-scaling-stroke"></path>
</svg>
</div>
<div class="flex justify-between mt-2 text-xxs text-text-secondary font-mono">
<span>Week 1</span>
<span>Week 6</span>
<span>Week 12</span>
</div>
<div class="mt-2 flex gap-4">
<div class="flex items-center gap-1.5">
<div class="w-3 h-0.5 bg-danger"></div>
<span class="text-xs text-text-secondary">High Risk Overrides</span>
</div>
<div class="flex items-center gap-1.5">
<div class="w-3 h-0.5 bg-success opacity-50 border-dashed border-t border-b-0"></div> <!-- Simulate dashed -->
<span class="text-xs text-text-secondary">Standard Approvals</span>
</div>
</div>
</div>
<!-- Decline Reasons -->
<div class="glass-panel rounded p-0 overflow-hidden">
<div class="px-4 py-3 border-b border-border-dark bg-surface-darker">
<h4 class="text-xs font-bold text-white uppercase">Primary Decline Reasons</h4>
</div>
<div class="p-0">
<div class="flex items-center p-3 border-b border-border-dark/50 hover:bg-surface-darker transition-colors">
<div class="text-xs font-mono text-text-secondary w-6">01</div>
<div class="flex-1 text-xs text-white font-medium">DSCR Below Policy</div>
<div class="text-xs font-mono text-danger">32%</div>
</div>
<div class="flex items-center p-3 border-b border-border-dark/50 hover:bg-surface-darker transition-colors">
<div class="text-xs font-mono text-text-secondary w-6">02</div>
<div class="flex-1 text-xs text-white font-medium">Sponsor Liquidity</div>
<div class="text-xs font-mono text-text-secondary">18%</div>
</div>
<div class="flex items-center p-3 border-b border-border-dark/50 hover:bg-surface-darker transition-colors">
<div class="text-xs font-mono text-text-secondary w-6">03</div>
<div class="flex-1 text-xs text-white font-medium">Tenant Concentration</div>
<div class="text-xs font-mono text-text-secondary">14%</div>
</div>
<div class="flex items-center p-3 border-b border-border-dark/50 hover:bg-surface-darker transition-colors">
<div class="text-xs font-mono text-text-secondary w-6">04</div>
<div class="flex-1 text-xs text-white font-medium">Appraisal Variance</div>
<div class="text-xs font-mono text-text-secondary">9%</div>
</div>
<div class="flex items-center p-3 hover:bg-surface-darker transition-colors">
<div class="text-xs font-mono text-text-secondary w-6">05</div>
<div class="flex-1 text-xs text-white font-medium">Environmental / ESA</div>
<div class="text-xs font-mono text-text-secondary">5%</div>
</div>
</div>
</div>
<!-- Committee Stats -->
<div class="glass-panel rounded p-5 flex flex-col justify-between">
<div class="flex justify-between items-start">
<h4 class="text-xs font-bold text-white uppercase">Committee Throughput</h4>
<div class="text-xxs text-primary bg-primary/10 border border-primary/20 px-2 py-1 rounded">Next: Oct 24</div>
</div>
<div class="grid grid-cols-2 gap-4 mt-4">
<div class="p-3 bg-surface-darker rounded border border-border-dark">
<div class="text-text-secondary text-xxs mb-1">Sessions (30d)</div>
<div class="text-xl font-bold text-white font-mono">12</div>
</div>
<div class="p-3 bg-surface-darker rounded border border-border-dark">
<div class="text-text-secondary text-xxs mb-1">Submit → Vote</div>
<div class="text-xl font-bold text-white font-mono">4.5d</div>
</div>
<div class="p-3 bg-surface-darker rounded border border-border-dark">
<div class="text-text-secondary text-xxs mb-1">Quorum Fails</div>
<div class="text-xl font-bold text-success font-mono">0</div>
</div>
<div class="p-3 bg-surface-darker rounded border border-border-dark">
<div class="text-text-secondary text-xxs mb-1">Revisions Req.</div>
<div class="text-xl font-bold text-warning font-mono">18</div>
</div>
</div>
</div>
</div>
</div>
</main>`;

export default function Page() {
  return (
    <StitchFrame
      title={TITLE}
      fontLinks={FONT_LINKS}
      tailwindCdnSrc={TAILWIND_CDN}
      tailwindConfigJs={TAILWIND_CONFIG_JS}
      styles={STYLES}
      bodyHtml={BODY_HTML}
    />
  );
}
