// src/app/ops/reminders/war-room/page.tsx
import WarRoom from "@/components/ops/reminders/WarRoom";

export const dynamic = "force-dynamic";

export default function RemindersWarRoomPage() {
  return <WarRoom />;
}
